from django.contrib import admin
from.models import Family
from.models import Charity
from.models import Business
from.models import Culture,Bookevent,Contact_us
admin.site.register(Family)
admin.site.register(Charity)
admin.site.register(Business)
admin.site.register(Culture)
admin.site.register(Bookevent)
admin.site.register(Contact_us)
